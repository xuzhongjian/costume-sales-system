INSERT INTO costume.area (id, is_deleted, create_at, update_at, area_name) VALUES (1, 0, '2019-12-08 12:52:56', '2019-12-08 12:52:56', '华北地区');
INSERT INTO costume.area (id, is_deleted, create_at, update_at, area_name) VALUES (2, 0, '2019-12-08 12:53:11', '2019-12-08 12:53:11', '东北地区');
INSERT INTO costume.area (id, is_deleted, create_at, update_at, area_name) VALUES (3, 0, '2019-12-08 12:53:34', '2019-12-08 12:53:34', '华东地区');
INSERT INTO costume.area (id, is_deleted, create_at, update_at, area_name) VALUES (4, 0, '2019-12-08 12:54:27', '2019-12-08 12:54:27', '中南地区');
INSERT INTO costume.area (id, is_deleted, create_at, update_at, area_name) VALUES (5, 0, '2019-12-08 12:54:58', '2019-12-08 12:54:58', '西南地区');
INSERT INTO costume.area (id, is_deleted, create_at, update_at, area_name) VALUES (6, 0, '2019-12-08 12:55:15', '2019-12-08 12:55:15', '西北地区');